// ===== CHARTS MANAGER =====

class ChartsManager {
  constructor() {
    this.charts = new Map();
    this.defaultOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 20,
            font: {
              family: 'Inter',
              size: 12
            }
          }
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          titleColor: '#fff',
          bodyColor: '#fff',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          borderWidth: 1,
          cornerRadius: 8,
          displayColors: true,
          titleFont: {
            family: 'Inter',
            size: 14,
            weight: '600'
          },
          bodyFont: {
            family: 'Inter',
            size: 12
          }
        }
      },
      scales: {
        x: {
          grid: {
            color: 'rgba(0, 0, 0, 0.05)',
            borderColor: 'rgba(0, 0, 0, 0.1)'
          },
          ticks: {
            font: {
              family: 'Inter',
              size: 11
            },
            color: '#6b7280'
          }
        },
        y: {
          grid: {
            color: 'rgba(0, 0, 0, 0.05)',
            borderColor: 'rgba(0, 0, 0, 0.1)'
          },
          ticks: {
            font: {
              family: 'Inter',
              size: 11
            },
            color: '#6b7280'
          }
        }
      }
    };

    this.colors = {
      primary: '#3b82f6',
      success: '#10b981',
      warning: '#f59e0b',
      error: '#ef4444',
      purple: '#8b5cf6',
      orange: '#f97316',
      pink: '#ec4899',
      indigo: '#6366f1',
      gray: '#6b7280'
    };

    this.gradients = {};
    this.init();
  }

  init() {
    // Set Chart.js defaults
    Chart.defaults.font.family = 'Inter';
    Chart.defaults.color = '#6b7280';
    
    // Initialize charts when DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.initializeCharts();
      });
    } else {
      this.initializeCharts();
    }
  }

  // Create gradient
  createGradient(ctx, color1, color2, direction = 'vertical') {
    const gradient = direction === 'vertical' 
      ? ctx.createLinearGradient(0, 0, 0, ctx.canvas.height)
      : ctx.createLinearGradient(0, 0, ctx.canvas.width, 0);
    
    gradient.addColorStop(0, color1);
    gradient.addColorStop(1, color2);
    
    return gradient;
  }

  // Get color with opacity
  getColorWithOpacity(color, opacity) {
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  }

  // Initialize all charts
  initializeCharts() {
    this.createAttendanceChart();
    this.createSpecialtyChart();
  }

  // Create attendance chart
  createAttendanceChart() {
    const canvas = document.getElementById('attendanceChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    
    // Create gradients
    const primaryGradient = this.createGradient(
      ctx, 
      this.getColorWithOpacity(this.colors.primary, 0.8),
      this.getColorWithOpacity(this.colors.primary, 0.1)
    );

    const successGradient = this.createGradient(
      ctx,
      this.getColorWithOpacity(this.colors.success, 0.8),
      this.getColorWithOpacity(this.colors.success, 0.1)
    );

    // Sample data
    const data = {
      labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
      datasets: [
        {
          label: 'Atendimentos Realizados',
          data: [120, 135, 145, 160, 155, 170, 180, 165, 175, 185, 190, 200],
          backgroundColor: primaryGradient,
          borderColor: this.colors.primary,
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: this.colors.primary,
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 5,
          pointHoverRadius: 7
        },
        {
          label: 'Meta Mensal',
          data: [150, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150, 150],
          backgroundColor: 'transparent',
          borderColor: this.colors.success,
          borderWidth: 2,
          borderDash: [5, 5],
          fill: false,
          pointRadius: 0,
          pointHoverRadius: 5
        }
      ]
    };

    const options = {
      ...this.defaultOptions,
      plugins: {
        ...this.defaultOptions.plugins,
        title: {
          display: false
        },
        legend: {
          ...this.defaultOptions.plugins.legend,
          position: 'top'
        }
      },
      scales: {
        ...this.defaultOptions.scales,
        y: {
          ...this.defaultOptions.scales.y,
          beginAtZero: true,
          max: 250
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      },
      animation: {
        duration: 2000,
        easing: 'easeInOutQuart'
      }
    };

    const chart = new Chart(ctx, {
      type: 'line',
      data: data,
      options: options
    });

    this.charts.set('attendance', chart);

    // Add animation on scroll
    this.addScrollAnimation(canvas, chart);
  }

  // Create specialty distribution chart
  createSpecialtyChart() {
    const canvas = document.getElementById('specialtyChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Sample data
    const data = {
      labels: ['Fisioterapia', 'Fonoaudiologia', 'Psicologia', 'Terapia Ocupacional', 'Pedagogia', 'Outros'],
      datasets: [{
        data: [35, 25, 20, 12, 5, 3],
        backgroundColor: [
          this.colors.primary,
          this.colors.success,
          this.colors.warning,
          this.colors.purple,
          this.colors.orange,
          this.colors.gray
        ],
        borderWidth: 0,
        hoverBorderWidth: 3,
        hoverBorderColor: '#fff'
      }]
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            usePointStyle: true,
            padding: 15,
            font: {
              family: 'Inter',
              size: 11
            },
            generateLabels: function(chart) {
              const data = chart.data;
              if (data.labels.length && data.datasets.length) {
                return data.labels.map((label, i) => {
                  const dataset = data.datasets[0];
                  const value = dataset.data[i];
                  const total = dataset.data.reduce((a, b) => a + b, 0);
                  const percentage = Math.round((value / total) * 100);
                  
                  return {
                    text: `${label} (${percentage}%)`,
                    fillStyle: dataset.backgroundColor[i],
                    strokeStyle: dataset.backgroundColor[i],
                    lineWidth: 0,
                    pointStyle: 'circle',
                    hidden: false,
                    index: i
                  };
                });
              }
              return [];
            }
          }
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          titleColor: '#fff',
          bodyColor: '#fff',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          borderWidth: 1,
          cornerRadius: 8,
          callbacks: {
            label: function(context) {
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = Math.round((context.parsed / total) * 100);
              return `${context.label}: ${context.parsed} (${percentage}%)`;
            }
          }
        }
      },
      animation: {
        animateRotate: true,
        animateScale: true,
        duration: 2000,
        easing: 'easeInOutQuart'
      }
    };

    const chart = new Chart(ctx, {
      type: 'doughnut',
      data: data,
      options: options
    });

    this.charts.set('specialty', chart);

    // Add animation on scroll
    this.addScrollAnimation(canvas, chart);
  }

  // Add scroll animation
  addScrollAnimation(canvas, chart) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          // Trigger chart animation
          chart.update('active');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.5
    });

    observer.observe(canvas);
  }

  // Update chart data
  updateChart(chartId, newData) {
    const chart = this.charts.get(chartId);
    if (!chart) return false;

    chart.data = newData;
    chart.update('active');
    return true;
  }

  // Add data to chart
  addData(chartId, label, data) {
    const chart = this.charts.get(chartId);
    if (!chart) return false;

    chart.data.labels.push(label);
    chart.data.datasets.forEach((dataset, index) => {
      dataset.data.push(data[index] || 0);
    });

    chart.update('active');
    return true;
  }

  // Remove data from chart
  removeData(chartId, index) {
    const chart = this.charts.get(chartId);
    if (!chart) return false;

    chart.data.labels.splice(index, 1);
    chart.data.datasets.forEach(dataset => {
      dataset.data.splice(index, 1);
    });

    chart.update('active');
    return true;
  }

  // Destroy chart
  destroyChart(chartId) {
    const chart = this.charts.get(chartId);
    if (!chart) return false;

    chart.destroy();
    this.charts.delete(chartId);
    return true;
  }

  // Destroy all charts
  destroyAll() {
    this.charts.forEach(chart => {
      chart.destroy();
    });
    this.charts.clear();
  }

  // Get chart instance
  getChart(chartId) {
    return this.charts.get(chartId);
  }

  // Create custom chart
  createChart(canvasId, type, data, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;

    const ctx = canvas.getContext('2d');
    const mergedOptions = this.mergeOptions(this.defaultOptions, options);

    const chart = new Chart(ctx, {
      type: type,
      data: data,
      options: mergedOptions
    });

    this.charts.set(canvasId, chart);
    return chart;
  }

  // Merge options
  mergeOptions(defaultOptions, customOptions) {
    const merged = JSON.parse(JSON.stringify(defaultOptions));
    
    function deepMerge(target, source) {
      for (const key in source) {
        if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
          if (!target[key]) target[key] = {};
          deepMerge(target[key], source[key]);
        } else {
          target[key] = source[key];
        }
      }
    }

    deepMerge(merged, customOptions);
    return merged;
  }

  // Export chart as image
  exportChart(chartId, filename = 'chart.png') {
    const chart = this.charts.get(chartId);
    if (!chart) return false;

    const url = chart.toBase64Image();
    const link = document.createElement('a');
    link.download = filename;
    link.href = url;
    link.click();

    return true;
  }

  // Resize all charts
  resizeAll() {
    this.charts.forEach(chart => {
      chart.resize();
    });
  }

  // Update theme for all charts
  updateTheme(isDark) {
    const textColor = isDark ? '#e5e7eb' : '#6b7280';
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)';

    this.charts.forEach(chart => {
      // Update scales colors
      if (chart.options.scales) {
        Object.keys(chart.options.scales).forEach(scaleKey => {
          const scale = chart.options.scales[scaleKey];
          if (scale.ticks) scale.ticks.color = textColor;
          if (scale.grid) scale.grid.color = gridColor;
        });
      }

      // Update legend colors
      if (chart.options.plugins && chart.options.plugins.legend) {
        chart.options.plugins.legend.labels.color = textColor;
      }

      chart.update('none');
    });
  }
}

// Create global instance
const chartsManager = new ChartsManager();

// Handle window resize
window.addEventListener('resize', Utils.debounce(() => {
  chartsManager.resizeAll();
}, 250));

// Export for use in other modules
window.ChartsManager = chartsManager;

