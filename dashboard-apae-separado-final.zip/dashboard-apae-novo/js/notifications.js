// ===== NOTIFICATION MANAGER =====

class NotificationManager {
  constructor() {
    this.notifications = [];
    this.container = null;
    this.maxNotifications = 5;
    this.defaultDuration = 5000;
    
    this.init();
  }

  init() {
    this.createContainer();
    this.setupEventListeners();
  }

  createContainer() {
    this.container = document.getElementById('toast-container');
    if (!this.container) {
      this.container = Utils.dom.create('div', {
        id: 'toast-container',
        className: 'toast-container'
      });
      document.body.appendChild(this.container);
    }
  }

  setupEventListeners() {
    // Listen for auth events
    window.addEventListener('auth:logout', () => {
      this.clear();
    });

    // Listen for online/offline events
    window.addEventListener('online', () => {
      this.show('Conexão restaurada', 'Você está online novamente.', 'success');
    });

    window.addEventListener('offline', () => {
      this.show('Sem conexão', 'Você está offline. Algumas funcionalidades podem não funcionar.', 'warning', {
        duration: 0 // Don't auto-dismiss
      });
    });
  }

  // Show notification
  show(title, message, type = 'info', options = {}) {
    const notification = this.createNotification(title, message, type, options);
    this.addNotification(notification);
    return notification.id;
  }

  // Show success notification
  success(title, message, options = {}) {
    return this.show(title, message, 'success', options);
  }

  // Show error notification
  error(title, message, options = {}) {
    return this.show(title, message, 'error', { duration: 0, ...options });
  }

  // Show warning notification
  warning(title, message, options = {}) {
    return this.show(title, message, 'warning', options);
  }

  // Show info notification
  info(title, message, options = {}) {
    return this.show(title, message, 'info', options);
  }

  // Create notification object
  createNotification(title, message, type, options) {
    const id = Utils.generateId();
    const duration = options.duration !== undefined ? options.duration : this.defaultDuration;
    
    return {
      id,
      title,
      message,
      type,
      duration,
      timestamp: Date.now(),
      options: {
        persistent: duration === 0,
        onClick: options.onClick,
        onClose: options.onClose,
        actions: options.actions || []
      }
    };
  }

  // Add notification to DOM and list
  addNotification(notification) {
    // Remove oldest notification if at max capacity
    if (this.notifications.length >= this.maxNotifications) {
      const oldest = this.notifications[0];
      this.remove(oldest.id);
    }

    // Add to list
    this.notifications.push(notification);

    // Create DOM element
    const element = this.createNotificationElement(notification);
    this.container.appendChild(element);

    // Animate in
    requestAnimationFrame(() => {
      element.classList.add('show');
    });

    // Auto-remove if not persistent
    if (!notification.options.persistent) {
      setTimeout(() => {
        this.remove(notification.id);
      }, notification.duration);
    }

    // Dispatch event
    window.dispatchEvent(new CustomEvent('notification:show', {
      detail: notification
    }));
  }

  // Create notification DOM element
  createNotificationElement(notification) {
    const element = Utils.dom.create('div', {
      className: `toast toast-${notification.type}`,
      'data-id': notification.id
    });

    // Icon
    const iconMap = {
      success: 'check',
      error: 'x',
      warning: 'alert-triangle',
      info: 'info'
    };

    const icon = Utils.dom.create('div', {
      className: 'toast-icon'
    });
    icon.innerHTML = `<i data-feather="${iconMap[notification.type]}"></i>`;

    // Content
    const content = Utils.dom.create('div', {
      className: 'toast-content'
    });

    const titleElement = Utils.dom.create('div', {
      className: 'toast-title',
      textContent: notification.title
    });

    const messageElement = Utils.dom.create('div', {
      className: 'toast-message',
      textContent: notification.message
    });

    content.appendChild(titleElement);
    content.appendChild(messageElement);

    // Actions
    if (notification.options.actions.length > 0) {
      const actionsContainer = Utils.dom.create('div', {
        className: 'toast-actions'
      });

      notification.options.actions.forEach(action => {
        const button = Utils.dom.create('button', {
          className: `btn btn-sm ${action.style || 'btn-ghost'}`,
          textContent: action.label
        });

        button.addEventListener('click', (e) => {
          e.stopPropagation();
          if (action.onClick) {
            action.onClick(notification);
          }
          if (action.dismiss !== false) {
            this.remove(notification.id);
          }
        });

        actionsContainer.appendChild(button);
      });

      content.appendChild(actionsContainer);
    }

    // Close button
    const closeButton = Utils.dom.create('button', {
      className: 'toast-close'
    });
    closeButton.innerHTML = '<i data-feather="x"></i>';
    closeButton.addEventListener('click', (e) => {
      e.stopPropagation();
      this.remove(notification.id);
    });

    // Assemble
    element.appendChild(icon);
    element.appendChild(content);
    element.appendChild(closeButton);

    // Click handler
    if (notification.options.onClick) {
      element.style.cursor = 'pointer';
      element.addEventListener('click', () => {
        notification.options.onClick(notification);
      });
    }

    // Replace feather icons
    feather.replace();

    return element;
  }

  // Remove notification
  remove(id) {
    const notification = this.notifications.find(n => n.id === id);
    if (!notification) return;

    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      // Animate out
      element.classList.remove('show');
      element.classList.add('notification-exit');

      setTimeout(() => {
        if (element.parentNode) {
          element.parentNode.removeChild(element);
        }
      }, 300);
    }

    // Remove from list
    this.notifications = this.notifications.filter(n => n.id !== id);

    // Call onClose callback
    if (notification.options.onClose) {
      notification.options.onClose(notification);
    }

    // Dispatch event
    window.dispatchEvent(new CustomEvent('notification:remove', {
      detail: notification
    }));
  }

  // Clear all notifications
  clear() {
    this.notifications.forEach(notification => {
      this.remove(notification.id);
    });
  }

  // Get notification by ID
  get(id) {
    return this.notifications.find(n => n.id === id);
  }

  // Get all notifications
  getAll() {
    return [...this.notifications];
  }

  // Update notification
  update(id, updates) {
    const notification = this.get(id);
    if (!notification) return false;

    // Update notification object
    Object.assign(notification, updates);

    // Update DOM element
    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      const titleElement = element.querySelector('.toast-title');
      const messageElement = element.querySelector('.toast-message');

      if (titleElement && updates.title) {
        titleElement.textContent = updates.title;
      }

      if (messageElement && updates.message) {
        messageElement.textContent = updates.message;
      }

      if (updates.type) {
        element.className = `toast toast-${updates.type} show`;
      }
    }

    return true;
  }

  // Show loading notification
  showLoading(title, message = 'Carregando...') {
    const id = this.show(title, message, 'info', {
      duration: 0,
      actions: []
    });

    // Add loading spinner
    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      const icon = element.querySelector('.toast-icon');
      icon.innerHTML = '<div class="loading-spinner"></div>';
    }

    return id;
  }

  // Update loading notification to success
  updateLoadingToSuccess(id, title, message) {
    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      const icon = element.querySelector('.toast-icon');
      icon.innerHTML = '<i data-feather="check"></i>';
      feather.replace();
      
      element.className = 'toast toast-success show';
    }

    this.update(id, { title, message, type: 'success' });

    // Auto-remove after delay
    setTimeout(() => {
      this.remove(id);
    }, 3000);
  }

  // Update loading notification to error
  updateLoadingToError(id, title, message) {
    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      const icon = element.querySelector('.toast-icon');
      icon.innerHTML = '<i data-feather="x"></i>';
      feather.replace();
      
      element.className = 'toast toast-error show';
    }

    this.update(id, { title, message, type: 'error' });
  }

  // Show confirmation notification
  showConfirmation(title, message, onConfirm, onCancel) {
    return this.show(title, message, 'warning', {
      duration: 0,
      actions: [
        {
          label: 'Cancelar',
          style: 'btn-ghost',
          onClick: () => {
            if (onCancel) onCancel();
          }
        },
        {
          label: 'Confirmar',
          style: 'btn-primary',
          onClick: () => {
            if (onConfirm) onConfirm();
          }
        }
      ]
    });
  }

  // Show progress notification
  showProgress(title, initialProgress = 0) {
    const id = Utils.generateId();
    const notification = {
      id,
      title,
      message: `${initialProgress}%`,
      type: 'info',
      duration: 0,
      timestamp: Date.now(),
      options: {
        persistent: true,
        progress: initialProgress
      }
    };

    this.notifications.push(notification);

    // Create custom element with progress bar
    const element = Utils.dom.create('div', {
      className: 'toast toast-info',
      'data-id': id
    });

    element.innerHTML = `
      <div class="toast-icon">
        <i data-feather="activity"></i>
      </div>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-progress">
          <div class="progress-bar">
            <div class="progress-fill" style="width: ${initialProgress}%"></div>
          </div>
          <span class="progress-text">${initialProgress}%</span>
        </div>
      </div>
      <button class="toast-close">
        <i data-feather="x"></i>
      </button>
    `;

    // Add event listeners
    const closeButton = element.querySelector('.toast-close');
    closeButton.addEventListener('click', () => {
      this.remove(id);
    });

    this.container.appendChild(element);
    feather.replace();

    requestAnimationFrame(() => {
      element.classList.add('show');
    });

    return id;
  }

  // Update progress notification
  updateProgress(id, progress, message) {
    const notification = this.get(id);
    if (!notification) return false;

    notification.options.progress = progress;
    if (message) notification.message = message;

    const element = this.container.querySelector(`[data-id="${id}"]`);
    if (element) {
      const progressFill = element.querySelector('.progress-fill');
      const progressText = element.querySelector('.progress-text');

      if (progressFill) {
        progressFill.style.width = `${progress}%`;
      }

      if (progressText) {
        progressText.textContent = message || `${progress}%`;
      }
    }

    // Auto-remove when complete
    if (progress >= 100) {
      setTimeout(() => {
        this.remove(id);
      }, 2000);
    }

    return true;
  }
}

// Create global instance
const notificationManager = new NotificationManager();

// Export for use in other modules
window.NotificationManager = notificationManager;

