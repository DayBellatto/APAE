// ===== DASHBOARD MANAGER =====

class DashboardManager {
  constructor() {
    this.currentPage = 'dashboard';
    this.sidebarCollapsed = false;
    this.isMobile = false;
    this.searchResults = [];
    this.theme = 'light';
    
    this.init();
  }

  init() {
    this.checkDevice();
    this.setupEventListeners();
    this.initializeTheme();
    this.setupSearch();
    this.setupNotifications();
    this.setupUserMenu();
    this.initializeAnimations();
    
    // Initialize after DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.initializeDashboard();
      });
    } else {
      this.initializeDashboard();
    }
  }

  checkDevice() {
    this.isMobile = Utils.device.isMobile();
    
    if (this.isMobile) {
      this.sidebarCollapsed = true;
      document.body.classList.add('mobile');
    }
  }

  setupEventListeners() {
    // Sidebar toggle
    const sidebarToggle = Utils.dom.$('#sidebar-toggle');
    const mobileMenuBtn = Utils.dom.$('#mobile-menu-btn');
    
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', () => {
        this.toggleSidebar();
      });
    }

    if (mobileMenuBtn) {
      mobileMenuBtn.addEventListener('click', () => {
        this.toggleMobileSidebar();
      });
    }

    // Navigation
    const navLinks = Utils.dom.$$('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        if (page) {
          this.navigateToPage(page);
        }
      });
    });

    // Window resize
    window.addEventListener('resize', Utils.debounce(() => {
      this.handleResize();
    }, 250));

    // Theme toggle
    const themeToggle = Utils.dom.$('#theme-toggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', () => {
        this.toggleTheme();
      });
    }

    // Logout
    const logoutBtn = Utils.dom.$('#logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        this.handleLogout();
      });
    }

    // Auth events
    window.addEventListener('auth:logout', () => {
      this.handleAuthLogout();
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
      this.closeDropdowns(e);
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      this.handleKeyboardShortcuts(e);
    });
  }

  initializeTheme() {
    const savedTheme = Utils.storage.get('theme', 'light');
    this.setTheme(savedTheme);
  }

  setTheme(theme) {
    this.theme = theme;
    document.body.className = document.body.className.replace(/\b(light|dark)-theme\b/g, '');
    document.body.classList.add(`${theme}-theme`);
    document.body.setAttribute('data-theme', theme);
    
    // Update theme toggle icon
    const themeToggle = Utils.dom.$('#theme-toggle i');
    if (themeToggle) {
      themeToggle.setAttribute('data-feather', theme === 'light' ? 'moon' : 'sun');
      feather.replace();
    }

    // Update charts theme
    if (window.ChartsManager) {
      ChartsManager.updateTheme(theme === 'dark');
    }

    Utils.storage.set('theme', theme);
  }

  toggleTheme() {
    const newTheme = this.theme === 'light' ? 'dark' : 'light';
    this.setTheme(newTheme);
    
    NotificationManager.success(
      'Tema alterado',
      `Tema ${newTheme === 'light' ? 'claro' : 'escuro'} ativado.`
    );
  }

  setupSearch() {
    const searchInput = Utils.dom.$('#global-search');
    const searchResults = Utils.dom.$('#search-results');
    
    if (!searchInput || !searchResults) return;

    const performSearch = Utils.debounce((query) => {
      if (query.length < 2) {
        this.hideSearchResults();
        return;
      }

      this.showSearchResults(this.mockSearch(query));
    }, 300);

    searchInput.addEventListener('input', (e) => {
      performSearch(e.target.value);
    });

    searchInput.addEventListener('focus', () => {
      if (searchInput.value.length >= 2) {
        this.showSearchResults(this.mockSearch(searchInput.value));
      }
    });

    searchInput.addEventListener('blur', () => {
      // Delay hiding to allow clicking on results
      setTimeout(() => {
        this.hideSearchResults();
      }, 200);
    });
  }

  mockSearch(query) {
    const mockData = [
      { type: 'patient', name: 'Maria Silva', id: '001', info: 'Fisioterapia' },
      { type: 'patient', name: 'João Santos', id: '002', info: 'Fonoaudiologia' },
      { type: 'staff', name: 'Dr. Ana Costa', id: '101', info: 'Fisioterapeuta' },
      { type: 'staff', name: 'Enf. Carlos Lima', id: '102', info: 'Enfermeiro' },
      { type: 'schedule', name: 'Escala Manhã', id: '201', info: 'Segunda-feira' },
      { type: 'schedule', name: 'Escala Tarde', id: '202', info: 'Terça-feira' }
    ];

    return mockData.filter(item => 
      item.name.toLowerCase().includes(query.toLowerCase()) ||
      item.info.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 5);
  }

  showSearchResults(results) {
    const searchResults = Utils.dom.$('#search-results');
    if (!searchResults) return;

    if (results.length === 0) {
      searchResults.innerHTML = '<div class="search-no-results">Nenhum resultado encontrado</div>';
    } else {
      const html = results.map(result => `
        <div class="search-result-item" data-type="${result.type}" data-id="${result.id}">
          <div class="search-result-icon">
            <i data-feather="${this.getSearchIcon(result.type)}"></i>
          </div>
          <div class="search-result-content">
            <div class="search-result-name">${result.name}</div>
            <div class="search-result-info">${result.info}</div>
          </div>
        </div>
      `).join('');
      
      searchResults.innerHTML = html;
      
      // Add click handlers
      searchResults.querySelectorAll('.search-result-item').forEach(item => {
        item.addEventListener('click', () => {
          this.handleSearchResultClick(item.dataset.type, item.dataset.id);
        });
      });
    }

    searchResults.style.display = 'block';
    feather.replace();
  }

  hideSearchResults() {
    const searchResults = Utils.dom.$('#search-results');
    if (searchResults) {
      searchResults.style.display = 'none';
    }
  }

  getSearchIcon(type) {
    const icons = {
      patient: 'user',
      staff: 'user-check',
      schedule: 'calendar'
    };
    return icons[type] || 'search';
  }

  handleSearchResultClick(type, id) {
    console.log(`Clicked on ${type} with ID ${id}`);
    this.hideSearchResults();
    
    // Navigate to appropriate page
    switch (type) {
      case 'patient':
        this.navigateToPage('patients');
        break;
      case 'staff':
        this.navigateToPage('staff');
        break;
      case 'schedule':
        this.navigateToPage('schedules');
        break;
    }
  }

  setupNotifications() {
    const notificationBtn = Utils.dom.$('.notification-btn');
    const notifications = Utils.dom.$('#notifications');
    
    if (notificationBtn && notifications) {
      notificationBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notifications.classList.toggle('open');
      });

      // Mark all as read
      const markAllRead = notifications.querySelector('.mark-all-read');
      if (markAllRead) {
        markAllRead.addEventListener('click', () => {
          this.markAllNotificationsRead();
        });
      }

      // Individual notification clicks
      const notificationItems = notifications.querySelectorAll('.notification-item');
      notificationItems.forEach(item => {
        item.addEventListener('click', () => {
          item.classList.remove('unread');
          this.updateNotificationBadge();
        });
      });
    }
  }

  markAllNotificationsRead() {
    const notifications = Utils.dom.$$('.notification-item.unread');
    notifications.forEach(item => {
      item.classList.remove('unread');
    });
    
    this.updateNotificationBadge();
    NotificationManager.success('Notificações', 'Todas as notificações foram marcadas como lidas.');
  }

  updateNotificationBadge() {
    const badge = Utils.dom.$('.notification-badge');
    const unreadCount = Utils.dom.$$('.notification-item.unread').length;
    
    if (badge) {
      if (unreadCount > 0) {
        badge.textContent = unreadCount;
        badge.style.display = 'block';
      } else {
        badge.style.display = 'none';
      }
    }
  }

  setupUserMenu() {
    const userMenu = Utils.dom.$('#user-menu');
    const userMenuBtn = userMenu?.querySelector('.user-menu-btn');
    
    if (userMenuBtn) {
      userMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        userMenu.classList.toggle('open');
      });
    }
  }

  closeDropdowns(e) {
    // Close notifications dropdown
    const notifications = Utils.dom.$('#notifications');
    if (notifications && !notifications.contains(e.target)) {
      notifications.classList.remove('open');
    }

    // Close user menu dropdown
    const userMenu = Utils.dom.$('#user-menu');
    if (userMenu && !userMenu.contains(e.target)) {
      userMenu.classList.remove('open');
    }
  }

  handleKeyboardShortcuts(e) {
    // Ctrl/Cmd + K for search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      const searchInput = Utils.dom.$('#global-search');
      if (searchInput) {
        searchInput.focus();
      }
    }

    // Escape to close dropdowns
    if (e.key === 'Escape') {
      this.closeDropdowns({ target: document.body });
      this.hideSearchResults();
    }
  }

  initializeDashboard() {
    this.updateUserInfo();
    this.animateStatsCards();
    this.startRealTimeUpdates();
    this.initializeScrollAnimations();
  }

  updateUserInfo() {
    const user = authManager.getCurrentUser();
    if (!user) return;

    // Update sidebar user info
    const sidebarUserName = Utils.dom.$('#sidebar-user-name');
    const sidebarUserRole = Utils.dom.$('#sidebar-user-role');
    const userNameHeader = Utils.dom.$('#user-name-header');
    const welcomeUserName = Utils.dom.$('#welcome-user-name');

    if (sidebarUserName) sidebarUserName.textContent = user.name;
    if (sidebarUserRole) sidebarUserRole.textContent = this.getRoleDisplayName(user.role);
    if (userNameHeader) userNameHeader.textContent = user.name;
    if (welcomeUserName) welcomeUserName.textContent = user.name;

    // Update avatar
    const avatars = Utils.dom.$$('.user-avatar img, .user-avatar-small');
    avatars.forEach(avatar => {
      if (user.avatar) {
        avatar.src = user.avatar;
      }
    });
  }

  getRoleDisplayName(role) {
    const roleNames = {
      admin: 'Administrador',
      doctor: 'Médico',
      nurse: 'Enfermeiro',
      user: 'Usuário'
    };
    return roleNames[role] || 'Usuário';
  }

  animateStatsCards() {
    const statNumbers = Utils.dom.$$('.stat-number');
    
    statNumbers.forEach(element => {
      const target = parseInt(element.dataset.target) || 0;
      Utils.animation.countUp(element, 0, target, 2000);
    });
  }

  startRealTimeUpdates() {
    // Update stats every 30 seconds
    setInterval(() => {
      this.updateRealTimeStats();
    }, 30000);

    // Update time every second
    setInterval(() => {
      this.updateCurrentTime();
    }, 1000);
  }

  updateRealTimeStats() {
    const statCards = Utils.dom.$$('.stat-card');
    
    statCards.forEach(card => {
      const numberElement = card.querySelector('.stat-number');
      if (numberElement) {
        const currentValue = parseInt(numberElement.textContent);
        const variation = Math.floor(Math.random() * 5) - 2; // -2 to +2
        const newValue = Math.max(0, currentValue + variation);
        
        if (newValue !== currentValue) {
          Utils.animation.countUp(numberElement, currentValue, newValue, 1000);
        }
      }
    });
  }

  updateCurrentTime() {
    const timeElements = Utils.dom.$$('.current-time');
    const now = new Date();
    const timeString = Utils.formatTime(now, { second: '2-digit' });
    
    timeElements.forEach(element => {
      element.textContent = timeString;
    });
  }

  initializeScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    // Observe elements with scroll reveal classes
    const scrollElements = Utils.dom.$$('.scroll-reveal, .scroll-reveal-left, .scroll-reveal-right');
    scrollElements.forEach(element => {
      observer.observe(element);
    });
  }

  initializeAnimations() {
    // Add stagger animation to stats grid
    const statsGrid = Utils.dom.$('.stats-grid');
    if (statsGrid) {
      statsGrid.classList.add('stagger-children');
    }

    // Add hover effects to cards
    const cards = Utils.dom.$$('.stat-card, .chart-card, .activity-card');
    cards.forEach(card => {
      card.classList.add('hover-lift');
    });
  }

  toggleSidebar() {
    const sidebar = Utils.dom.$('#sidebar');
    if (!sidebar) return;

    this.sidebarCollapsed = !this.sidebarCollapsed;
    sidebar.classList.toggle('collapsed', this.sidebarCollapsed);
    
    Utils.storage.set('sidebarCollapsed', this.sidebarCollapsed);
  }

  toggleMobileSidebar() {
    const sidebar = Utils.dom.$('#sidebar');
    if (!sidebar) return;

    sidebar.classList.toggle('open');
  }

  navigateToPage(page) {
    // Update navigation
    const navItems = Utils.dom.$$('.nav-item');
    navItems.forEach(item => {
      item.classList.remove('active');
      const link = item.querySelector('.nav-link');
      if (link && link.dataset.page === page) {
        item.classList.add('active');
      }
    });

    // Update breadcrumb
    this.updateBreadcrumb(page);

    // Show page content
    this.showPage(page);

    // Close mobile sidebar
    if (this.isMobile) {
      const sidebar = Utils.dom.$('#sidebar');
      if (sidebar) {
        sidebar.classList.remove('open');
      }
    }

    this.currentPage = page;
  }

  updateBreadcrumb(page) {
    const breadcrumb = Utils.dom.$('.breadcrumb');
    if (!breadcrumb) return;

    const pageNames = {
      dashboard: 'Visão Geral',
      patients: 'Pacientes',
      staff: 'Funcionários',
      schedules: 'Escalas',
      reports: 'Relatórios',
      settings: 'Configurações'
    };

    const currentItem = breadcrumb.querySelector('.current');
    if (currentItem) {
      currentItem.textContent = pageNames[page] || page;
    }
  }

  showPage(page) {
    // Hide all pages
    const pages = Utils.dom.$$('.page');
    pages.forEach(p => {
      p.style.display = 'none';
    });

    // Show selected page
    const targetPage = Utils.dom.$(`#${page}-page`);
    if (targetPage) {
      targetPage.style.display = 'block';
      
      // Add entrance animation
      targetPage.classList.remove('animate-fade-in-up');
      requestAnimationFrame(() => {
        targetPage.classList.add('animate-fade-in-up');
      });
    }
  }

  handleResize() {
    const wasMobile = this.isMobile;
    this.checkDevice();

    // Handle mobile/desktop transition
    if (wasMobile !== this.isMobile) {
      const sidebar = Utils.dom.$('#sidebar');
      if (sidebar) {
        if (this.isMobile) {
          sidebar.classList.remove('collapsed');
          sidebar.classList.remove('open');
        } else {
          sidebar.classList.remove('open');
          const savedCollapsed = Utils.storage.get('sidebarCollapsed', false);
          sidebar.classList.toggle('collapsed', savedCollapsed);
          this.sidebarCollapsed = savedCollapsed;
        }
      }
    }
  }

  handleLogout() {
    NotificationManager.showConfirmation(
      'Confirmar saída',
      'Tem certeza que deseja sair do sistema?',
      () => {
        authManager.logout();
      }
    );
  }

  handleAuthLogout() {
    // Clear any dashboard-specific data
    this.currentPage = 'dashboard';
    this.searchResults = [];
    
    // Show login screen
    this.showScreen('login-screen');
  }

  showScreen(screenId) {
    const screens = Utils.dom.$$('.screen');
    screens.forEach(screen => {
      screen.classList.remove('active');
    });

    const targetScreen = Utils.dom.$(`#${screenId}`);
    if (targetScreen) {
      targetScreen.classList.add('active');
    }
  }

  // Public methods for external use
  refreshStats() {
    this.animateStatsCards();
  }

  showNotification(title, message, type = 'info') {
    NotificationManager.show(title, message, type);
  }

  getCurrentPage() {
    return this.currentPage;
  }

  isPageActive(page) {
    return this.currentPage === page;
  }
}

// Create global instance
const dashboardManager = new DashboardManager();

// Export for use in other modules
window.DashboardManager = dashboardManager;

